    <?php

    $this->load->view('home/home/beranda');

    ?>

    <div class="container">
        <?= $data->panduan ?>
    </div>